create table Customer(
	mobile_number varchar2(10) primary key,
	name varchar2(30),
	Balance number(7,2)
);